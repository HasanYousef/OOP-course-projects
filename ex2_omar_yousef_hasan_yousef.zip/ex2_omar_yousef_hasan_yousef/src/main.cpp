﻿#pragma once
#include <iostream>
using namespace std;

#include "Macros.h"
#include "Controller.h"

int main()
{
	Controller game;
	game.run();

	return EXIT_SUCCESS;
}

#include "Controller.h"

int main()
{
	Controller controller;
	controller.run();

	return EXIT_SUCCESS;
}
